import { RefreshCw, FileSpreadsheet, FileText, Eye, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const projects = [
  {
    id: 1,
    name: "Final Database Test",
    description: "asdasd...",
    client: "Test Construction Co",
    amount: "$23,333",
    state: "Texas",
    prelimDeadline: "February 17, 2026",
    lienDeadline: "March 16, 2026",
    reminder: "1 day, 7 days",
  },
  {
    id: 2,
    name: "Final Database Test",
    description: "asdasd...",
    client: "Test Construction Co",
    amount: "$2,322,323",
    state: "Texas",
    prelimDeadline: "February 17, 2026",
    lienDeadline: "March 16, 2026",
    reminder: null,
  },
];

export const ProjectsTable = () => {
  return (
    <div className="bg-card rounded-xl overflow-hidden border border-border card-shadow">
      <div className="p-6 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-lg font-semibold text-foreground">Your Projects</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="border-border hover:bg-muted">
            <RefreshCw className="h-4 w-4 mr-1.5" />
            Refresh
          </Button>
          <Button size="sm" className="bg-success hover:bg-success/90 text-success-foreground">
            <FileSpreadsheet className="h-4 w-4 mr-1.5" />
            Export to CSV
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent bg-muted/50">
              <TableHead className="text-foreground font-semibold">Project</TableHead>
              <TableHead className="text-foreground font-semibold">Client</TableHead>
              <TableHead className="text-foreground font-semibold">Amount</TableHead>
              <TableHead className="text-foreground font-semibold">State</TableHead>
              <TableHead className="text-foreground font-semibold">Prelim Deadline</TableHead>
              <TableHead className="text-foreground font-semibold">Lien Deadline</TableHead>
              <TableHead className="text-foreground font-semibold">Reminders</TableHead>
              <TableHead className="text-foreground font-semibold text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((project) => (
              <TableRow key={project.id} className="border-border hover:bg-muted/30">
                <TableCell>
                  <div>
                    <p className="font-medium text-foreground">{project.name}</p>
                    <p className="text-xs text-muted-foreground">{project.description}</p>
                  </div>
                </TableCell>
                <TableCell className="text-foreground">{project.client}</TableCell>
                <TableCell className="font-semibold text-foreground">{project.amount}</TableCell>
                <TableCell>
                  <Badge className="bg-warning/15 text-warning border-warning/30 hover:bg-warning/20">
                    {project.state}
                  </Badge>
                </TableCell>
                <TableCell className="text-foreground">{project.prelimDeadline}</TableCell>
                <TableCell className="text-foreground">{project.lienDeadline}</TableCell>
                <TableCell>
                  {project.reminder ? (
                    <Badge className="bg-info/15 text-info border-info/30">
                      <Calendar className="h-3 w-3 mr-1" />
                      {project.reminder}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground text-sm">None</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center justify-end gap-2">
                    <Button size="sm" className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                      <FileText className="h-4 w-4" />
                    </Button>
                    <Button size="sm" className="bg-success hover:bg-success/90 text-success-foreground">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
