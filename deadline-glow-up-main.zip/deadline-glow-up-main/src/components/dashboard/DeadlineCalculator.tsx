import { Calendar, MapPin, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const states = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado",
  "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho",
  "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
  "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
  "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
  "New Hampshire", "New Jersey", "New Mexico", "New York",
  "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
  "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
  "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
  "West Virginia", "Wisconsin", "Wyoming"
];

export const DeadlineCalculator = () => {
  return (
    <div className="bg-card rounded-xl p-6 border border-border card-shadow">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
          <Calculator className="h-5 w-5 text-primary-foreground" />
        </div>
        <h2 className="text-lg font-semibold text-foreground">Calculate New Deadline</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-sm text-foreground flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            Invoice/Delivery Date
          </Label>
          <Input
            type="date"
            defaultValue="2025-12-30"
            className="bg-background border-border focus:border-primary focus:ring-primary/20"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-foreground flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            State
          </Label>
          <Select>
            <SelectTrigger className="bg-background border-border focus:border-primary focus:ring-primary/20">
              <SelectValue placeholder="Select a state..." />
            </SelectTrigger>
            <SelectContent className="bg-card border-border">
              {states.map((state) => (
                <SelectItem key={state} value={state.toLowerCase().replace(" ", "-")}>
                  {state}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Button className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 text-base">
        <Calculator className="h-5 w-5 mr-2" />
        Calculate Deadlines
      </Button>
    </div>
  );
};
